# -*- coding:utf8 -*-
from Base import myunit
from urllib import request
import unittest
import os,sys
class zhangtest(myunit.MyTest):
    def test_char1(self):
        myrequest = request.urlopen('https://www.baidu.com')
        # x=myrequest.read().decode('utf-8')
        status = myrequest.getcode()
        self.assertEqual(status, 200)


if __name__ == "__main__":
    unittest.main()



