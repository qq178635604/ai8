# -*- coding:utf8 -*-
"""
用来存放测试用例
"""
from time import sleep
import unittest,sys
# from selenium.webdriver.common.by import By
sys.path.append("./models")
sys.path.append("./page_obj")
from models import myunit,function
from page_obj.chatPage import chat
class request(myunit.MyTest):
    def to_iframe(self):
        self.driver.switch_to.frame('xhe0_iframe')
    def user_login_verify(self):
        chat(self.driver).user_login()
    def switch_handl(self):
        a=self.driver.window_handles
        self.driver.switch_to.window(a[1])
    def java_s(self):
        js = 'var q=document.documentElement.scrollTop=8000'
        self.driver.execute_script(js)
    def test_chat1(self):
        """无内容回复"""
        self.user_login_verify()
        sleep(2)
        re=chat(self.driver)
        re.link_tie()
        sleep(2)
        self.switch_handl()
        self.java_s()
        sleep(2)
        re.chat_but()
        sleep(5)
        self.assertEqual(re.empy_click(),'内容不能小于2个字符')
        function.insert_img(self.driver, "chat_test1.jpg")
    def test_chat2(self):
        """一字符回复"""
        self.user_login_verify()
        sleep(2)
        re=chat(self.driver)
        re.link_tie()
        sleep(2)
        self.switch_handl()
        self.java_s()
        sleep(2)
        self.to_iframe()
        self.driver.find_element_by_tag_name('body').send_keys('很')
        self.driver.switch_to.default_content()
        re.chat_but()
        sleep(2)
        self.assertEqual(re.empy_click(), '内容不能小于2个字符')
        function.insert_img(self.driver, "chat_test2.jpg")
    def test_chat3(self):
        """回复为两空格字符"""
        self.user_login_verify()
        sleep(2)
        re = chat(self.driver)
        re.link_tie()
        sleep(2)
        self.switch_handl()
        self.java_s()
        sleep(2)
        self.to_iframe()
        self.driver.find_element_by_tag_name('body').send_keys('  ')
        self.driver.switch_to.default_content()
        re.chat_but()
        sleep(2)
        self.assertEqual(re.empy_click(), '内容不能小于2个字符')
        function.insert_img(self.driver, "chat_test3.jpg")
if __name__=="__main__":
    unittest.main()