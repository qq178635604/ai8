# -*- coding:utf8 -*-
'''
用于存放基本功能方法
'''
from selenium.webdriver.common.by import By
from .base import Page
from time import sleep
class chat(Page):
    url = '/tieba/'
    # 登录用户名文本框定位
    login_username_loc = (By.ID, 'logname')
    # 登录密码文本框定位
    login_password_loc = (By.ID, 'logpwd')
    # 登录按钮定位
    login_button_loc = (By.ID, 'loginimg')
    #帖子定位
    link_tie_loc=(By.CSS_SELECTOR,'#topiclist > div:nth-child(4) >.topic_show_l >.topic_show_con >.topic_show_tit > a')
    #发布按钮
    chat_but_loc=(By.ID,'EditSubmit')
    #无内容报错定位
    empy_click_loc=(By.XPATH,'//td[@style="width: auto; height: auto;"]/div[@style="padding: 10px;"]')
    #一字符报错
    one_char_loc=(By.CSS_SELECTOR,'#mainContent > div:nth-child(2) > table > tbody > tr:nth-child(2) >.ui_c > div > table > tbody > tr:nth-child(2) >.ui_main > div')
    def login_username(self, username):
        self.find_element(*self.login_username_loc).send_keys(username)
    def login_password(self, password):
        self.find_element(*self.login_password_loc).send_keys(password)
    def login_button(self):
        self.find_element(*self.login_button_loc).click()
    def user_login(self, username="13825769024", password="qq6894129"):
        self.open()
        self.login_username(username)
        self.login_password(password)
        self.login_button()
        sleep(2)
    #帖子链接
    def link_tie(self):
        return self.find_element(*self.link_tie_loc).click()
    #发布按钮
    def chat_but(self):
        return self.find_element(*self.chat_but_loc).click()
    #无内容报错
    def empy_click(self):
        return self.find_element(*self.empy_click_loc).text
    #一字符报错
    def one_char(self):
        return self.find_element(*self.one_char_loc).text