# -*- coding:utf8 -*-
"""
运行开关
"""
from email.mime.text import MIMEText
from email.header import Header
from email.utils import parseaddr, formataddr
import smtplib
from HTMLTestRunner import HTMLTestRunner
import unittest
import time
#格式化地址信息
# def _format_addr(s):
#     name, addr = parseaddr(s)
#     return formataddr((Header(name, 'utf-8').encode(), addr))
# def send_email(newfile):
#     # 输入SMTP服务器地址:
#     smtp_server = 'smtp.126.com'
#     # 输入Email地址和口令:
#     from_addr = 'qq178635604@126.com'
#     password = 'zc6894129'
#     # 输入收件人地址:
#     to_addr = '178635604@qq.com'
#     #读取最新文件
#     with open(newfile,"rb") as f:
#         mail_body=f.read()
#     #定义邮件格式
#     msg=MIMEText(mail_body,'html','utf-8')
#     #定义文件头信息与文本内容
#     msg['From'] = Header('测试人员<%s>'% from_addr, 'utf-8')
#     msg['To'] = to_addr
#     msg['Subject']=Header('测试报告','utf-8')
#     #用指定的smtp发送文件，端口25
#     smtp=smtplib.SMTP(smtp_server,25)
#     #文件发送调试模式开启
#     smtp.set_debuglevel(1)
#     smtp.helo(smtp_server)
#     smtp.ehlo(smtp_server)
#     #登录邮箱smtp
#     smtp.login(from_addr,password)
#     #发送邮件并转码
#     smtp.sendmail(_format_addr(from_addr),_format_addr(to_addr),msg.as_string())
#     smtp.quit()
#     #发送完成后输出邮件发送
#     print('邮件已发送！')
#获取当前路径下的最新文件
# def new_file(test_dir):
#     #列举test_dir目录下的所有文件，结果以列表形式返回。
#     lists=os.listdir(test_dir)
#     #sort按key的关键字进行排序，lambda的入参fn为lists列表的元素，获取文件的最后修改时间
#     #最后对lists元素，按文件修改时间大小从小到大排序。
#     lists.sort(key=lambda fn:os.path.getmtime(test_dir+'\\'+fn))
#     #获取最新文件的绝对路径
#     file_path=os.path.join(test_dir,lists[-1])
#     return file_path

if __name__=="__main__":
    #将时间转成字符串以一定格式输出
    now = time.strftime("%Y-%m-%d %H_%M_%S")
    #生成文件路径
    filename='./TestReport/'+now+'result.html'
    #打开读取文件并发送
    with open(filename, "wb",) as f:
        #报告主题设置
        runner = HTMLTestRunner(stream=f,title='自动化测试报告',description='环境：windows7 浏览器：chrome')
        #查找指定路径下的以_sta.py结尾的所有文件并运行
        discover=unittest.defaultTestLoader.discover('./TestCase', pattern='*_sta.py', top_level_dir=None)
        runner.run(discover)
    # #指定生成报告目录
    # file_path= new_file("./pauyang/report/")
    # #发送邮件
    # send_email(file_path)